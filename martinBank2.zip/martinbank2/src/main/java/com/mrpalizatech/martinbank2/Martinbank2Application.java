package com.mrpalizatech.martinbank2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Martinbank2Application {

	public static void main(String[] args) {
		SpringApplication.run(Martinbank2Application.class, args);
	}

}
